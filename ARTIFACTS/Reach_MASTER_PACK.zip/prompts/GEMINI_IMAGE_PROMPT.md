# Reach – Gemini Image Pro Hero Prompt

Create a 4K (3840x2160) 16:9 hero image for **Reach** (distributed agent orchestration).

Scene: midnight-blue global horizon with atmospheric gradient.
Nodes activate across continents; connection arcs glow in deep violet + cool white.
Foreground: modular agent blocks assembling cleanly (marketplace/orchestration metaphor).

Mood: scale, coordination, emergent intelligence.
Avoid: particle chaos, sci‑fi clichés, neon overload.
Leave headline-safe negative space (center).
